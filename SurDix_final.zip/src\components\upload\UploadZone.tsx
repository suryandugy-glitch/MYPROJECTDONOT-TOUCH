import { useState } from 'react';

interface UploadZoneProps {
  onUpload: (file: File) => Promise<void>;
  uploadStatus?: 'idle' | 'uploading' | 'processing' | 'success' | 'error';
  progress?: number;
}

export function UploadZone({
  onUpload,
  uploadStatus = 'idle',
  progress = 0
}: UploadZoneProps) {
  const [dragActive, setDragActive] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragActive(false);
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragActive(false);

    const droppedFile = e.dataTransfer?.files[0];
    if (droppedFile) {
      await handleFile(droppedFile);
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      await handleFile(selectedFile);
    }
    // Reset input to allow same file to be selected again
    e.target.value = '';
  };

  const handleFile = async (selectedFile: File) => {
    // Basic validation
    if (selectedFile.type !== 'application/zip') {
      setError('Please upload a ZIP file');
      return;
    }

    // Check file size (e.g., 50MB limit)
    const MAX_SIZE_MB = 50;
    if (selectedFile.size > MAX_SIZE_MB * 1024 * 1024) {
      setError(`File size exceeds ${MAX_SIZE_MB}MB limit`);
      return;
    }

    setFile(selectedFile);
    setError(null);
    setSuccess(null);

    try {
      setUploading(true);
      await onUpload(selectedFile);
      setSuccess('Upload successful! Deployment started.');
    } catch (err: any) {
      setError(err.message ?? 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div
      className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition-border duration-200 dark:border-gray-600 dark:hover:border-gray-500"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <input
        type="file"
        id="file-upload"
        className="hidden"
        accept=".zip"
        onChange={handleFileSelect}
      />
      <label htmlFor="file-upload" className="cursor-pointer">
        {dragActive ? (
          <div className="space-y-3">
            <p className="text-indigo-600 font-medium dark:text-indigo-400">Release to upload</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">Or drag & drop another file</p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-center space-x-3">
              <svg className="h-6 w-6 text-indigo-500 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16v4H3m11-8l-3 3m0 0l3 3m-3-3h3.586a2 2 0 001.414-.586l6.293-6.293a2 2 0 000-2.828l-2.121-2.121a2 2 0 000-2.828 0L12 8.414V3a2 2 0 10-4 0v4.414z" />
              </svg>
            </div>
            <p className="text-gray-600 dark:text-gray-400">
              Click to upload or drag and drop a ZIP file containing your static website
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Maximum file size: 50MB
            </p>
          </div>
        )}
      </label>

      {file && !uploading && !error && !success && (
        <div className="mt-4">
          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Selected file:</p>
          <p className="text-sm text-gray-500 dark:text-gray-400 truncate">{file.name}</p>
          <button
            onClick={() => {
              setFile(null);
            }}
            className="mt-2 px-3 py-1 text-sm font-medium text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300"
          >
            Change file
          </button>
        </div>
      )}

      {uploading && (
        <div className="mt-4">
          <div className="flex items-center space-x-3">
            <div className="h-4 w-4 border-2 border-indigo-500 rounded-full border-t-transparent animate-spin" />
            <p className="text-sm text-gray-600 dark:text-gray-400">Uploading...</p>
          </div>
        </div>
      )}

      {error && (
        <div className="mt-4 bg-red-50 dark:bg-red-900 border-l-4 border-red-500 p-4">
          <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
        </div>
      )}

      {success && (
        <div className="mt-4 bg-green-50 dark:bg-green-900 border-l-4 border-green-500 p-4">
          <p className="text-sm text-green-700 dark:text-green-300">{success}</p>
        </div>
      )}

      {/* Progress bar from parent component */}
      {(uploadStatus === 'uploading' || uploadStatus === 'processing') && progress > 0 && progress < 100 && (
        <div className="mt-4">
          <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {uploadStatus === 'uploading' ? 'Uploading to Supabase Storage...' : 'Deploying to Cloudflare Pages...'}
          </p>
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
            <div
              className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
          <p className="text-right text-sm text-gray-500 dark:text-gray-400 mt-1">
            {progress}%
          </p>
        </div>
      )}
    </div>
  );
}