# SurDix - Free Static Website Hosting Platform

SurDix is a free static website hosting platform that allows users to upload their website files and publish them to the internet with a public URL. The goal is to make website publishing as simple as uploading a ZIP file.

## Features

- **Simple Deployment**: Upload a ZIP file containing your static website and deploy it in seconds
- **User Authentication**: Secure sign-up, login, and account management using Supabase Auth
- **Project Management**: Dashboard to view, manage, redeploy, and delete your projects
- **Free Tier**: Host your websites for free using generous free tiers from Supabase and Cloudflare Pages
- **Static Sites Only**: We only host pre-built static websites (HTML, CSS, JS) for security
- **Responsive Design**: Modern, developer-first interface that works on all devices

## Technology Stack

- **Frontend**: React, Vite, TypeScript, Tailwind CSS
- **Authentication**: Supabase Auth
- **Database**: Supabase PostgreSQL
- **Hosting**: Cloudflare Pages (free tier)
- **State Management**: React Context API
- **Routing**: React Router

## Getting Started

### Prerequisites

- Node.js (v16 or higher)
- npm (v7 or higher)
- Git
- Supabase account
- Cloudflare account

### Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd surdix
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file based on `.env.example`:
   ```bash
   cp .env.example .env
   ```

4. Fill in your environment variables:
   ```
   VITE_SUPABASE_URL=your_supabase_project_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_public_key
   CLOUDFLARE_ACCOUNT_ID=your_cloudflare_account_id
   CLOUDFLARE_API_TOKEN=your_cloudflare_api_token
   ```

5. Set up your Supabase database:
   - Follow the instructions in `SUPABASE_SETUP.md`
   - Run the SQL commands to create tables and set up RLS policies

6. Set up your Cloudflare Pages project:
   - Follow the instructions in `HOSTING_SETUP.md`
   - Create a Cloudflare Pages project for deployments

7. Start the development server:
   ```bash
   npm run dev
   ```

8. Open your browser to `http://localhost:5173`

## Project Structure

```
surdix/
├── public/                 # Static assets
├── src/
│   ├── components/         # Reusable components
│   │   ├── Layout.tsx      # Main layout with header
│   │   ├── RequireAuth.tsx # Protected route wrapper
│   │   └── upload/         # Upload-related components
│   ├── context/            # React context providers
│   │   └── AuthContext.tsx # Authentication context
│   ├── lib/                # Utility functions and services
│   │   └── supabase.ts     # Supabase client initialization
│   ├── routes/             # Page components
│   │   ├── Dashboard.tsx   # User dashboard (protected)
│   │   ├── Features.tsx    # Features page
│   │   ├── Home.tsx        # Landing page
│   │   ├── Login.tsx       # Login page
│   │   ├── Signup.tsx      # Signup page
│   │   └── Upload.tsx      # Upload page (protected)
│   ├── App.tsx             # Main app component with routing
│   ├── index.css           # Tailwind CSS directives
│   └── main.tsx            # Entry point
├── .env.example            # Example environment variables
├── index.html              # Main HTML file
├── package.json            # Project dependencies and scripts
├── postcss.config.js       # PostCSS configuration
├── tailwind.config.cjs     # Tailwind CSS configuration
├── tsconfig.json           # TypeScript configuration
├── vite.config.ts          # Vite configuration
└── README.md               # This file
```

## Environment Variables

Create a `.env` file in the root directory with the following variables:

| Variable | Description | Example |
|----------|-------------|---------|
| `VITE_SUPABASE_URL` | Your Supabase project URL | `https://xyzcompany.supabase.co` |
| `VITE_SUPABASE_ANON_KEY` | Your Supabase anon public key | `public-anon-key` |
| `CLOUDFLARE_ACCOUNT_ID` | Your Cloudflare account ID | `0123456789abcdef0123456789abcdef` |
| `CLOUDFLARE_API_TOKEN` | Your Cloudflare API token (with Pages edit permissions) | `your-cloudflare-api-token` |

**Important**: Never commit your `.env` file to version control. The `.env.example` file shows the required variables without exposing actual values.

## Database Setup

Run the SQL commands in `SUPABASE_SETUP.md` to create the necessary tables and configure Row Level Security (RLS) policies.

The schema includes:
- `profiles` table for user profile information
- `projects` table for website projects
- `deployments` table for tracking deployment attempts

## Hosting Provider Setup

SurDix uses Cloudflare Pages for hosting static websites. Follow the instructions in `HOSTING_SETUP.md` to:

1. Create a Cloudflare account
2. Generate an API token with appropriate permissions
3. Set up a Cloudflare Pages project
4. Configure environment variables

## Available Scripts

In the project directory, you can run:

- `npm run dev` - Starts the development server
- `npm run build` - Builds the app for production
- `npm run preview` - Previews the production build
- `npm run lint` - Runs the linter

## Deployment Instructions

### Development

1. Start the development server:
   ```bash
   npm run dev
   ```

2. The app will be available at `http://localhost:5173`

### Production

1. Build the app:
   ```bash
   npm run build
   ```

2. The built files will be in the `dist/` directory

3. Deploy the `dist/` directory to your preferred hosting provider

## Security Considerations

SurDix implements several security measures:

1. **Authentication**: All user authentication is handled by Supabase Auth, which provides secure password storage and session management.

2. **Authorization**: Row Level Security (RLS) policies ensure users can only access their own data.

3. **File Validation**: 
   - Only ZIP files are accepted
   - File size is limited (default 50MB)
   - Path traversal and symlink attacks are prevented
   - Requires index.html at the root of the ZIP

4. **API Security**: 
   - Supabase service role key is never exposed to the client
   - Cloudflare API token is kept server-only
   - All deployment operations happen through secure backend endpoints

5. **Content Safety**: 
   - Only static websites are hosted (no server-side code execution)
   - JavaScript runs in users' browsers, isolated from the main platform
   - Abuse reporting and takedown workflows are planned

## Limitations

### Free Tier Constraints

- **Supabase**: 
  - 500 MB database storage
  - 2 GB file storage
  - 500 MB bandwidth

- **Cloudflare Pages**: 
  - 500 build minutes per month
  - 10,000 unique requests per day
  - 100 GB bandwidth per month

These limits are sufficient for testing and low-traffic personal projects. For higher usage, consider upgrading to paid plans.

### Known Limitations in Current Implementation

1. The upload and deployment functionality is currently mocked - real integration with Cloudflare Pages API needs to be implemented
2. Database operations are not yet connected - Supabase integration needs completion
3. Email verification and password recovery are not fully implemented
4. Custom domain support is planned for future versions
5. Rate monitoring and abuse prevention measures need implementation

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contact

For questions or support, please open an issue in the repository.

## Acknowledgments

- [Supabase](https://supabase.com) for authentication and database
- [Cloudflare Pages](https://pages.cloudflare.com) for free static website hosting
- [Vite](https://vitejs.dev) for the fast frontend build tool
- [React](https://reactjs.org) for the frontend library
- [Tailwind CSS](https://tailwindcss.com) for the utility-first CSS framework
