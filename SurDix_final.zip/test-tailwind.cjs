const tailwindcss = require("./node_modules/tailwindcss/dist/lib.js");

tailwindcss.compile({
  content: [
    {
      raw: "<h1 class='text-3xl font-bold text-center text-gray-900 mb-6'>Test Heading</h1><p class='text-xl text-center text-gray-600 mb-4'>This is a test.</p><button class='rounded-md bg-indigo-600 px-6 py-3 text-lg font-medium text-white hover:bg-indigo-700 transition-all duration-300'>Test Button</button>",
      extension: "html"
    }
  ],
  tailwindConfig: {
    content: [],
    theme: {
      extend: {}
    },
    darkMode: 'class'
  }
}).then(result => {
  console.log('Build function:', result.build);
  return result.build();
}).then(css => {
  console.log('CSS result:', css);
  if (typeof css === 'string') {
    console.log('CSS content:', css);
  }
}).catch(error => {
  console.error(error);
});