import { RequireAuth } from '../components/RequireAuth';
import { useState, useEffect } from 'react';

// Mock project data - in a real implementation, this would come from Supabase
const mockProjects = [
  {
    id: '1',
    name: 'My Portfolio',
    slug: 'my-portfolio',
    status: 'deployed',
    deploymentProvider: 'cloudflare_pages',
    deploymentId: 'deploy-123',
    publishedUrl: 'https://my-portfolio.pages.dev',
    createdAt: '2023-05-15T10:30:00Z',
    updatedAt: '2023-05-15T14:22:00Z',
    deployments: [
      {
        id: 'dep-1',
        status: 'deployed',
        deploymentId: 'deploy-123',
        publishedUrl: 'https://my-portfolio.pages.dev',
        createdAt: '2023-05-15T10:30:00Z',
        completedAt: '2023-05-15T10:35:00Z'
      }
    ]
  },
  {
    id: '2',
    name: 'Blog Site',
    slug: 'blog-site',
    status: 'failed',
    deploymentProvider: 'cloudflare_pages',
    deploymentId: 'deploy-456',
    publishedUrl: null,
    createdAt: '2023-05-10T14:15:00Z',
    updatedAt: '2023-05-10T16:45:00Z',
    deployments: [
      {
        id: 'dep-2',
        status: 'failed',
        deploymentId: 'deploy-456',
        publishedUrl: null,
        errorMessage: 'Build failed: Missing index.html',
        createdAt: '2023-05-10T14:15:00Z',
        completedAt: '2023-05-10T14:20:00Z'
      }
    ]
  },
  {
    id: '3',
    name: 'Documentation',
    slug: 'documentation',
    status: 'deploying',
    deploymentProvider: 'cloudflare_pages',
    deploymentId: 'deploy-789',
    publishedUrl: null,
    createdAt: '2023-05-20T09:00:00Z',
    updatedAt: '2023-05-20T09:05:00Z',
    deployments: [
      {
        id: 'dep-3',
        status: 'deploying',
        deploymentId: 'deploy-789',
        publishedUrl: null,
        createdAt: '2023-05-20T09:00:00Z',
        completedAt: null
      }
    ]
  }
];

export function Dashboard() {
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error] = useState<string | null>(null);

  // In a real implementation, this would fetch data from Supabase
  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setProjects(mockProjects);
      setLoading(false);
    }, 1000);
  }, []);

  return (
    <RequireAuth>
      <div className="bg-white dark:bg-gray-900">
        <header className="bg-white dark:bg-gray-800 shadow-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex">
                <div className="flex-shrink-0 flex items-center">
                  <span className="text-xl font-semibold text-indigo-600 dark:text-indigo-400">SurDix Dashboard</span>
                </div>
              </div>
              <div className="hidden md:block">
                <div className="ml-10 flex items-baseline space-x-4">
                  <a href="#" className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200">Features</a>
                  <a href="#" className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200">How It Works</a>
                  <a href="#" className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200">Documentation</a>
                </div>
              </div>
              <div className="flex items-center">
                <div className="ml-4 flex items-baseline space-x-4">
                  <a href="/login" className="text-sm font-medium text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300">Log in</a>
                  <a href="/signup" className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-medium text-white hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-400">Sign up</a>
                </div>
              </div>
            </div>
          </div>
        </header>
        <main className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {loading ? (
              <div className="text-center py-12">
                <div className="flex items-center justify-center mb-4">
                  <div className="h-8 w-8 border-2 border-indigo-500 rounded-full border-t-transparent animate-spin" />
                </div>
                <p className="text-gray-600 dark:text-gray-400">Loading your projects...</p>
              </div>
            ) : error ? (
              <div className="text-center py-12">
                <p className="text-red-600 dark:text-red-400">{error}</p>
              </div>
            ) : projects.length === 0 ? (
              <div className="text-center py-16">
                <div className="flex items-center justify-center mb-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 rounded-full flex items-center justify-center text-white">
                    <svg className="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.1 0-2 .9-2 2s.9 2 2-2-1.8-2-2-2zm0 12c-4 0-6 2-6 4h2c0-1.1.9-2 2-2s2-.9 2-2h2c-2 0-4-2-4-4h-2c0-2.2-1.4-3.9-3.6-4.4zm13.2 0c-.4 0-.7.3-.7.7s.3.7.7.7h8c.4 0 .7-.3 .7-.7s-.3-.7-.7-.7h-8z" />
                    </svg>
                  </div>
                </div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">
                  No projects yet
                </h2>
                <p className="text-gray-600 dark:text-gray-400 max-w-lg mx-auto">
                  Upload your first static website to get started.
                </p>
                <a
                  href="/upload"
                  className="mt-6 inline-block rounded-md bg-indigo-600 px-5 py-3 text-sm font-medium text-white hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-400 transition-all duration-300 transform hover:-translate-y-1 hover:scale-[1.02] shadow-lg shadow-indigo-500/20"
                >
                  Upload Website
                </a>
              </div>
            ) : (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-6">
                  Your Projects
                </h2>
                <div className="divide-y divide-gray-200 dark:divide-gray-700">
                  {projects.map((project) => (
                    <div key={project.id} className="py-6">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                            {project.name}
                          </h3>
                          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                            Created: {new Date(project.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="ml-4 flex items-baseline space-x-3">
                          {project.deployments && project.deployments.length > 0 ? (
                            <>
                              {project.deployments.map((deploy: any) => (
                                <div key={deploy.id} className="flex items-center space-x-2 text-sm">
                                  {deploy.status === 'success' || deploy.status === 'deployed' ? (
                                    <>
                                      <span className="text-green-600">Live</span>
                                      <a
                                        href={deploy.publishedUrl}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300 underline"
                                      >
                                        Visit
                                      </a>
                                    </>
                                  ) : (
                                    <span className={deploy.status === 'deploying' || deploy.status === 'pending' ? 'text-blue-600' : 'text-red-600'}>
                                      {deploy.status === 'deploying' || deploy.status === 'pending' ? 'Deploying…' : 'Failed'}
                                    </span>
                                  )}
                                </div>
                              ))}
                            </>
                          ) : (
                            <span className="text-gray-500 dark:text-gray-400">No deployments yet</span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </RequireAuth>
  );
}
