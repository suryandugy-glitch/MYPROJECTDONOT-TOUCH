import { Link } from 'react-router-dom';

export function Home() {

  return (
    <div className="bg-white dark:bg-gray-900">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="relative z-10">
          {/* Animated background shapes */}
          <div className="absolute inset-0 -z-10">
            <div className="relative h-96">
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-500 via-purple-600 to-pink-500 opacity-20"></div>
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 1440 320%22><path fill=%22%23ffffff%22 fill-opacity=%220.1%22 d=%22M0,224L48,256C96,288,192,288,224,256C384,224,480,288,528,256C672,224,816,288,960,256C1104,224,1248,288,1344,256L1392,32L1440,0H0Z%22 />%22) /auto translate-y-full"></div>
            </div>
          </div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
            <h1 className="text-4xl font-bold text-center text-gray-900 dark:text-gray-100 mb-6">
              From ZIP to Live Website.
            </h1>
            <p className="text-xl text-center text-gray-600 dark:text-gray-400 mb-10 max-w-2xl mx-auto">
              Upload your static website, deploy it in seconds, and share it with the world.
              Simple hosting for builders.
            </p>
            <div className="flex justify-center space-x-6">
              <Link
                to="/dashboard"
                className="rounded-md bg-indigo-600 px-6 py-3 text-lg font-medium text-white hover:bg-indigo-700 transition-all duration-300 transform hover:-translate-y-1 hover:scale-[1.02] shadow-lg shadow-indigo-500/20"
              >
                Deploy Your First Site
              </Link>
              <Link
                to="/features"
                className="rounded-md border border-gray-300 dark:border-gray-600 px-6 py-3 text-lg font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-all duration-300 transform hover:-translate-y-1 hover:scale-[1.02]"
              >
                Explore Features
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-gray-100 mb-12">
            See how it works
          </h2>
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {/* Upload Card */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
              <div className="flex items-center justify-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 rounded-full flex items-center justify-center text-white text-2xl">
                  <svg className="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h18m0 0v18m0-18h-18m18 0v-6a4 4 0 00-4-4H5a4 4 0 00-4 4v6m0 0v6m0 0h6a4 4 0 004 4h4a4 4 0 004-4v-4a4 4 0 01-4-4h2a4 4 0 014 4v4a4 4 0 004 4h-4a4 4 0 00-4-4h-2v4a4 4 0 01-4 4h-2v-4a4 4 0 00-4-4h-2v2a4 4 0 01-4 4h2a4 4 0 004-4h2v-4a4 4 0 014-4h2a4 4 0 004 4z" />
                  </svg>
                </div>
              </div>
              <h3 className="text-2xl font-bold text-center text-gray-900 dark:text-gray-100 mb-4">1. Upload</h3>
              <p className="text-center text-gray-600 dark:text-gray-400">
                Drag and drop your website ZIP file or click to select.
              </p>
            </div>

            {/* Deploy Card */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
              <div className="flex items-center justify-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 rounded-full flex items-center justify-center text-white text-2xl">
                  <svg className="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.1 0-2 .9-2 2s.9 2 2-2-1.8-2, -2, -2, -.1, 8, -2, -2, -2zm0 12c-4 0-6 2-6 4h2c0-1.1.9-2 2-2s2-.9 2-2h2c-2 0-4-2-4-4h-2c0-2.2-1.4-3.9-3.6-4.4zm13.2 0c-.4 0-.7.3-.7.7s.3.7.7.7h8c.4 0 .7-.3 .7-.7s-.3-.7-.7-.7h-8z" />
                  </svg>
                </div>
              </div>
              <h3 className="text-2xl font-bold text-center text-gray-900 dark:text-gray-100 mb-4">2. Deploy</h3>
              <p className="text-center text-gray-600 dark:text-gray-400">
                We handle the deployment to our global CDN in seconds.
              </p>
            </div>

            {/* Share Card */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
              <div className="flex items-center justify-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 rounded-full flex items-center justify-center text-white text-2xl">
                  <svg className="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M16 14h.01M9 16H5a2 2 0 01-2-2V5a2 2 0 012-2h10a2 2 0 012 2v9a2 2 0 01-2 2H9zm12 0a2 2 0 012-2V5a2 2 0 01-2-2h2a2 2 0 012 2v9a2 2 0 01-2 2h12a2 2 0 00-2 2z" />
                  </svg>
                </div>
              </div>
              <h3 className="text-2xl font-bold text-center text-gray-900 dark:text-gray-100 mb-4">3. Share</h3>
              <p className="text-center text-gray-600 dark:text-gray-400">
                Get a public URL and share your site with the world.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Dashboard Preview */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-gray-100 mb-12">
            Manage your projects
          </h2>
          <div className="bg-gray-50 dark:bg-gray-800 rounded-xl shadow-lg p-8">
            <div className="space-y-6">
              {/* Project Card 1 */}
              <div className="flex items-center justify-between bg-white dark:bg-gray-800 rounded-lg p-6 hover:shadow-xl transition-all duration-300">
                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 rounded-full flex items-center justify-center text-white">
                      <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7 20h10a2 2 0 002-2V6a2 2 0 00-2-2H7a2 2 0 00-2-2v12a2 2 0 002 2z" />
                      </svg>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">My Portfolio</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Deployed 2 hours ago</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Link
                    to="/dashboard"
                    className="text-sm font-medium text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300 transition-colors duration-200"
                  >
                    View
                  </Link>
                  <button
                    className="rounded-md bg-indigo-600 px-3 py-1 text-sm font-medium text-white hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-400 transition-colors duration-200"
                  >
                    Redeploy
                  </button>
                  <button
                    className="text-sm font-medium text-red-500 hover:text-red-600 dark:text-red-400 dark:hover:text-red-300 transition-colors duration-200"
                  >
                    Delete
                  </button>
                </div>
              </div>

              {/* Project Card 2 */}
              <div className="flex items-center justify-between bg-white dark:bg-gray-800 rounded-lg p-6 hover:shadow-xl transition-all duration-300">
                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 rounded-full flex items-center justify-center text-white">
                      <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7h18M3 12h18M3 17h18" />
                      </svg>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">Blog Site</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Deployment failed</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <button
                    className="text-sm font-medium text-red-500 hover:text-red-600 dark:text-red-400 dark:hover:text-red-300 transition-colors duration-200"
                  >
                    Retry
                  </button>
                </div>
              </div>

              {/* Empty State */}
              <div className="text-center py-12">
                <div className="flex items-center justify-center mb-6">
                  <div className="w-20 h-20 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 rounded-full flex items-center justify-center text-white">
                    <svg className="h-10 w-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.1 0-2 .9-2 2s.9 2 2-2-1.8-2-2-2zm0 12c-4 0-6 2-6 4h2c0-1.1.9-2 2-2s2-.9 2-2h2c-2 0-4-2-4-4h-2c0-2.2-1.4-3.9-3.6-4.4zm13.2 0c-.4 0-.7.3-.7.7s.3.7.7.7h8c.4 0 .7-.3 .7-.7s-.3-.7-.7-.7h-8z" />
                    </svg>
                  </div>
                </div>
                <h3 className="text-xl font-bold text-center text-gray-900 dark:text-gray-100 mb-4">No projects yet</h3>
                <p className="text-center text-gray-600 dark:text-gray-400 max-w-lg mx-auto">
                  Upload your first static website to get started.
                </p>
                <Link
                  to="/upload"
                  className="mt-6 rounded-md bg-indigo-600 px-5 py-3 text-lg font-medium text-white hover:bg-indigo-700 transition-all duration-300 transform hover:-translate-y-1 hover:scale-[1.02] shadow-lg shadow-indigo-500/20"
                >
                  Upload Website
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-gray-100 mb-12">
            Features
          </h2>
          <p className="text-center text-gray-600 dark:text-gray-400 mb-8">
            Learn more about what SurDix offers.
          </p>
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {/* Static Sites Only */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
              <h3 className="text-2xl font-bold text-center text-gray-900 dark:text-gray-100 mb-4">Static Sites Only</h3>
              <p className="text-center text-gray-600 dark:text-gray-400">
                We only host pre-built static websites (HTML, CSS, JS). No backend
                code execution for security.
              </p>
            </div>

            {/* Free Tier */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
              <h3 className="text-2xl font-bold text-center text-gray-900 dark:text-gray-100 mb-4">Free Tier</h3>
              <p className="text-center text-gray-600 dark:text-gray-400">
                Host your first sites for free using generous free tiers from
                Supabase and Cloudflare Pages.
              </p>
            </div>

            {/* Custom Domains */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
              <h3 className="text-2xl font-bold text-center text-gray-900 dark:text-gray-100 mb-4">Custom Domains</h3>
              <p className="text-center text-gray-600 dark:text-gray-400">
                Use your own domain or a subdomain under surdix.example (coming
                soon).
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Ready to deploy your first site?
          </h2>
          <p className="text-xl text-indigo-100 mb-8 max-w-lg mx-auto">
            Sign up now and get started in seconds.
          </p>
          <Link
            to="/signup"
            className="rounded-md bg-white px-6 py-3 text-lg font-medium text-indigo-600 hover:bg-indigo-50 dark:text-indigo-600 dark:hover:bg-indigo-400 transition-all duration-300 transform hover:-translate-y-1 hover:scale-[1.02] shadow-lg shadow-indigo-500/20"
          >
            Get Started Free
          </Link>
        </div>
      </section>
    </div>
  );
}