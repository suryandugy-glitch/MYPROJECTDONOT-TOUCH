# SurDix Database Schema

## Overview

This document describes the database schema for SurDix, a free static website hosting platform.

## Tables

### 1. Profiles

Stores additional user information beyond what's in Supabase auth.users.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PRIMARY KEY, references auth.uid | User ID (matches auth.users.id) |
| display_name | TEXT |  | User's display name |
| created_at | TIMESTAMP WITH TIME ZONE | DEFAULT timezone('utc', now()), NOT NULL | Account creation timestamp |

### 2. Projects

Represents a user's website project.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PRIMARY KEY, DEFAULT uuid_generate_v4() | Unique project identifier |
| user_id | UUID | NOT NULL, references auth.uid | Owner of the project |
| name | TEXT | NOT NULL | Human-readable project name |
| slug | TEXT | UNIQUE, NOT NULL | URL-friendly identifier for the project |
| status | TEXT | NOT NULL DEFAULT 'pending' | Current status: pending, deploying, deployed, failed |
| deployment_provider | TEXT | NOT NULL | Provider used (e.g., 'cloudflare_pages') |
| deployment_id | TEXT |  | ID from the deployment provider |
| published_url | TEXT |  | Live URL of the deployed website |
| created_at | TIMESTAMP WITH TIME ZONE | DEFAULT timezone('utc', now()), NOT NULL | Creation timestamp |
| updated_at | TIMESTAMP WITH TIME ZONE | DEFAULT timezone('utc', now()), NOT NULL | Last update timestamp |

### 3. Deployments

Tracks individual deployment attempts for projects.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PRIMARY KEY, DEFAULT uuid_generate_v4() | Unique deployment identifier |
| project_id | UUID | NOT NULL, references projects(id) | Associated project |
| user_id | UUID | NOT NULL, references auth.uid | User who initiated deployment |
| status | TEXT | NOT NULL | Status: pending, deploying, deployed, failed |
| deployment_id | TEXT |  | ID from the deployment provider |
| published_url | TEXT |  | Live URL from this deployment |
| error_message | TEXT |  | Error details if deployment failed |
| created_at | TIMESTAMP WITH TIME ZONE | DEFAULT timezone('utc', now()), NOT NULL | When deployment started |
| completed_at | TIMESTAMP WITH TIME ZONE |  | When deployment finished |

## Relationships

- One user can have many profiles (1:1 with auth.users)
- One user can have many projects (1:Many)
- One project can have many deployments (1:Many)
- One user can have many deployments (1:Many)

## Indexes

For performance, we should add these indexes:

```sql
-- Projects indexes
CREATE INDEX idx_projects_user_id ON projects(user_id);
CREATE INDEX idx_projects_slug ON projects(slug);
CREATE INDEX idx_projects_status ON projects(status);

-- Deployments indexes
CREATE INDEX idx_deployments_project_id ON deployments(project_id);
CREATE INDEX idx_deployments_user_id ON deployments(user_id);
CREATE INDEX idx_deployments_status ON deployments(status);
CREATE INDEX idx_deployments_created_at ON deployments(created_at);
```

## Row Level Security (RLS) Policies

All tables have RLS enabled with policies ensuring users can only access their own data.

### Profiles Policies
- Users can view their own profile
- Users can update their own profile

### Projects Policies
- Users can view their own projects
- Users can insert their own projects
- Users can update their own projects
- Users can delete their own projects

### Deployments Policies
- Users can view their own deployments
- Users can insert their own deployments
- Users can update their own deployments
- Users can delete their own deployments

## Triggers

Automatically update the `updated_at` and `completed_at` timestamps:

```sql
-- For projects table
CREATE TRIGGER update_projects_updated_at
    BEFORE UPDATE ON projects
    FOR EACH ROW
    EXECUTE FUNCTION moddatetime (updated_at);

-- For deployments table
CREATE TRIGGER update_deployments_updated_at
    BEFORE UPDATE ON deployments
    FOR EACH ROW
    EXECUTE FUNCTION moddatetime (completed_at);
```

Note: The `moddatetime` function is a Supabase helper function that sets a column to the current time.

## Constraints and Validation

### Projects Table Constraints
- `name` cannot be empty
- `slug` must be unique across all projects
- `status` must be one of: pending, deploying, deployed, failed
- `deployment_provider` must be a valid provider name

### Deployments Table Constraints
- `status` must be one of: pending, deploying, deployed, failed
- `project_id` must reference an existing project
- `user_id` must reference an existing user

## Extensions

Required PostgreSQL extensions:
- `uuid-ossp` for generating UUIDs

## Indexing Strategy

Primary access patterns:
1. Get user's projects (by user_id)
2. Get project by slug (for public access)
3. Get deployments for a project (by project_id)
4. Get recent deployments (by created_at)
5. Get user's deployments (by user_id)

The indexes listed above support these patterns efficiently.

## Migration Notes

This schema is designed to be migrated using Supabase's migration system or manual SQL execution.

When modifying the schema in the future:
1. Add new columns as nullable with defaults where appropriate
2. Consider data migration needs for existing records
3. Update RLS policies if new tables/columns are added
4. Test migrations on a copy of production data first
