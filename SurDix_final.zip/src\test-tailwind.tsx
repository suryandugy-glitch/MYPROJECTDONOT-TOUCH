export function TestTailwind() {
  return (
    <div className="text-red-500">
      Test Tailwind
    </div>
  );
}