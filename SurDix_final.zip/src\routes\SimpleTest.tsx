export function SimpleTest() {
  return (
    <div>
      <h1>Simple Test</h1>
    </div>
  );
}
