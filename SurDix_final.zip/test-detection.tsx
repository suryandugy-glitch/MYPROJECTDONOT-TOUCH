import React from 'react';

export function TestDetection() {
  return (
    <div className="bg-white dark:bg-gray-900 text-4xl font-bold text-center text-gray-900 dark:text-gray-100 mb-6">
      Test Detection
    </div>
  );
}