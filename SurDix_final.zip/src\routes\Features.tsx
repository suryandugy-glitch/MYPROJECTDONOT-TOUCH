export function Features() {
  return (
    <div className="bg-white">
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-center text-gray-900 mb-8">
            Features
          </h2>
          <p className="text-center text-gray-600 mb-8">
            Learn more about what SurDix offers.
          </p>
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Static Sites Only</h3>
              <p className="text-gray-600">
                We only host pre-built static websites (HTML, CSS, JS). No backend
                code execution for security.
              </p>
            </div>
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Free Tier</h3>
              <p className="text-gray-600">
                Host your first sites for free using generous free tiers from
                Supabase and Cloudflare Pages.
              </p>
            </div>
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Custom Domains</h3>
              <p className="text-gray-600">
                Use your own domain or a subdomain under surdix.example (coming
                soon).
              </p>
            </div>
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Instant Deployments</h3>
              <p className="text-gray-600">
                Deployments happen in seconds, not minutes.
              </p>
            </div>
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Global CDN</h3>
              <p className="text-gray-600">
                Your sites are served from edge locations worldwide for fast
                loading.
              </p>
            </div>
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Automatic SSL</h3>
              <p className="text-gray-600">
                Free SSL certificates for all domains, automatically renewed.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
