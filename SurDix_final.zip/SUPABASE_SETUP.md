# Supabase Setup Instructions

## Creating a Supabase Project

1. Go to [supabase.com](https://supabase.com) and sign up/log in
2. Click "New Project"
3. Fill in the project details:
   - Name: surdix (or similar)
   - Database Password: [generate a strong password]
   - Region: Choose closest to your users
4. Click "Create new project"

## Getting API Keys

Once your project is ready:
1. Go to Project Settings → API
2. Copy:
   - Project URL (under "Project API keys")
   - anon public key (under "Project API keys")
   - service_role key (under "Project API keys") - for server-side only

## Environment Variables

Create a `.env` file in the root of your project:

```
VITE_SUPABASE_URL=your_project_url
VITE_SUPABASE_ANON_KEY=your_anon_public_key
# SERVICE_ROLE_KEY=your_service_role_key  # For server-side only, never expose to client
```

## Database Schema

Run these SQL commands in the Supabase SQL editor to set up the database:

```sql
-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- Profiles table
create table profiles (
  id uuid references auth.uid not null primary key,
  display_name text,
  created_at timestamp with time zone default timezone('utc', now()) not null
);

-- Projects table
create table projects (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references auth.uid not null,
  name text not null,
  slug text unique not null,
  status text not null default 'pending', -- pending, deploying, deployed, failed
  deployment_provider text not null, -- e.g., 'cloudflare_pages'
  deployment_id text, -- ID from the deployment provider
  published_url text,
  created_at timestamp with time zone default timezone('utc', now()) not null,
  updated_at timestamp with time zone default timezone('utc', now()) not null
);

-- Deployments table
create table deployments (
  id uuid default uuid_generate_v4() primary key,
  project_id uuid references projects not null,
  user_id uuid references auth.uid not null,
  status text not null, -- pending, deploying, deployed, failed
  deployment_id text, -- ID from the deployment provider
  published_url text,
  error_message text,
  created_at timestamp with time zone default timezone('utc', now()) not null,
  completed_at timestamp with time zone
);

-- Enable Row Level Security
alter table profiles enable row level security;
alter table projects enable row level security;
alter table deployments enable row level security;

-- Profiles RLS Policies
create policy "Users can view their own profile"
  on profiles for select
  using (auth.uid() = id);

create policy "Users can update their own profile"
  on profiles for update
  using (auth.uid() = id);

-- Projects RLS Policies
create policy "Users can view their own projects"
  on projects for select
  using (auth.uid() = user_id);

create policy "Users can insert their own projects"
  on projects for insert
  with check (auth.uid() = user_id);

create policy "Users can update their own projects"
  on projects for update
  using (auth.uid() = user_id);

create policy "Users can delete their own projects"
  on projects for delete
  using (auth.uid() = user_id);

-- Deployments RLS Policies
create policy "Users can view their own deployments"
  on deployments for select
  using (auth.uid() = user_id);

create policy "Users can insert their own deployments"
  on deployments for insert
  with check (auth.uid() = user_id);

create policy "Users can update their own deployments"
  on deployments for update
  using (auth.uid() = user_id);

create policy "Users can delete their own deployments"
  on deployments for delete
  using (auth.uid() = user_id);

-- Updated at trigger for projects
create trigger update_projects_updated_at
  before update on projects
  for each row
  execute procedure moddatetime (updated_at);

-- Updated at trigger for deployments
create trigger update_deployments_updated_at
  before update on deployments
  for each row
  execute procedure moddatetime (completed_at);
```

## Storage for ZIP Files (Optional)

If you want to store the uploaded ZIP files in Supabase Storage:

1. Create a bucket called "website-uploads"
2. Set up appropriate security policies

Note: For security, consider immediately extracting and deploying the ZIP rather than storing it long-term.
