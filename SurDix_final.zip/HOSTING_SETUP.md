# Hosting Provider Setup Instructions

## Cloudflare Pages Setup (Recommended for Free Tier)

Cloudflare Pages offers a generous free tier suitable for SurDix:
- 500 builds per month
- 10,000 unique requests per day
- 100 GB bandwidth per month
- Custom domains included
- Free SSL certificates

### Creating a Cloudflare Account

1. Go to [cloudflare.com](https://cloudflare.com) and sign up
2. Verify your email address

### Getting API Token

To programmatically create deployments, you'll need an API token:

1. In Cloudflare dashboard, go to My Profile → API Tokens
2. Click "Create Token"
3. Choose "Custom Token" template
4. Configure permissions:
   - Account → Account Settings → Read
   - Account → Workers Scripts → Edit
   - Account → Pages → Edit
5. Optional: Restrict to specific account(s)
6. Optional: Restrict IP addresses for security
7. Click "Continue to summary"
8. Click "Create Token"
9. Copy the token - you won't see it again!

### Alternative: Cloudflare API Key (Less Secure)

If you prefer to use the global API key:
1. Go to My Profile → API Tokens
2. Click "Global API Key"
3. Click "View" to see your key
4. Copy the key (this is less secure than scoped tokens)

### Environment Variables

Add these to your `.env` file (NEVER commit to git):

```
# Cloudflare
CLOUDFLARE_ACCOUNT_ID=your_account_id
CLOUDFLARE_API_TOKEN=your_api_token  # or API key
# For server-side only
```

### Finding Your Account ID

1. In Cloudflare dashboard, look at the URL when viewing your account
2. It will be something like `https://dash.cloudflare.com/:account_id`
3. Or go to Account Home → Account Configure → Account ID

### Project Structure in Cloudflare Pages

For SurDix, we have two options:

#### Option 1: Single Project with Multiple Deployments (Recommended)
- Create one Cloudflare Pages project
- Each deployment creates a unique preview deployment
- Use deployment IDs to track each user's site
- Limited by build minutes (500/month free)

#### Option 2: Separate Project per User
- Create a new Cloudflare Pages project for each user
- More isolated but quickly hits limits
- Not recommended for free tier

We'll implement Option 1 as it's more suitable for the free tier.

### Deployment Process

When a user uploads a ZIP:
1. Extract ZIP to temporary directory
2. Verify it contains index.html at root
3. Use Cloudflare API to create a deployment:
   ```
   POST https://api.cloudflare.com/client/v4/accounts/:account_id/pages/projects/:project_id/deployments
   ```
4. Include the extracted files in the deployment
5. Cloudflare returns a deployment ID and URL
6. Store deployment ID and URL in database
7. Return URL to user

### Limitations to Consider

Free tier limits:
- 500 build minutes per month
- Each deployment uses build minutes
- Need to monitor usage and potentially warn users
- Consider implementing builds on demand rather than preview deployments
- Alternative: Use Cloudflare Pages' "Projects" feature with manual uploads via API

## Alternative Hosting Providers

If Cloudflare Pages doesn't work out, consider:

### Netlify
- Free tier: 300 build minutes/month, 100 GB bandwidth
- Similar API for programmatic deployments
- Site creation limits may apply

### Vercel
- Free tier: 100 GB bandwidth, 1000 serverless function executions
- Site creation limits on hobby account
- API for deployments

### Firebase Hosting
- Free tier: 10 GB storage, 10 GB/month download
- Custom domains require paid plan
- CLI-based deployment

## Security Considerations

1. Never expose API keys to client-side code
2. Use server-side proxy for deployment API calls
3. Implement rate limiting to prevent abuse
4. Validate all file inputs to prevent malicious uploads
5. Consider sandboxing the deployment process
6. Implement cleanup policies for old deployments
