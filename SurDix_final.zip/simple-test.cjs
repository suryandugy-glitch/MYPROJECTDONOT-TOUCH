const fs = require("fs");
const tailwindcss = require("./node_modules/tailwindcss/dist/lib.js");

// Read the input CSS file
const inputCss = fs.readFileSync("./src/index.css", "utf8");

tailwindcss.compile({
  content: [
    {
      raw: "<h1 class='text-red-500'>This is a test</h1>",
      extension: "html"
    }
  ],
  tailwindConfig: {
    content: [],
    theme: {
      extend: {}
    }
  }
}).then(result => {
  console.log('Result properties:', Object.keys(result));
  // Try to get the CSS using the build method
  // Based on the source code, build() should return the processed CSS
  const builtCss = result.build();
  console.log('Built CSS type:', typeof builtCss);
  if (typeof builtCss === 'string') {
    console.log('Generated CSS length:', builtCss.length);
    console.log('First 500 chars:', builtCss.substring(0, 500));
  } else {
    console.log('Built CSS is not a string:', typeof builtCss);
    // Let's see what it is
    console.log('Built CSS:', builtCss);
  }
}).catch(error => {
  console.error('Error:', error);
});