import { useState } from 'react';

interface ProjectFormProps {
  onSubmit: (projectName: string) => Promise<void>;
  projectName?: string;
  onProjectNameChange?: (projectName: string) => void;
}

export function ProjectForm({
  onSubmit,
  projectName = '',
  onProjectNameChange
}: ProjectFormProps) {
  const [localProjectName, setLocalProjectName] = useState(projectName);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [charCount, setCharCount] = useState(localProjectName.length);

  // Update local state when prop changes
  // In a real implementation, we might use useEffect, but for simplicity we'll handle it in the onChange

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setSubmitting(true);

    try {
      // Basic validation
      if (!localProjectName.trim()) {
        setError('Please enter a project name');
        return;
      }

      // Check for valid characters (alphanumeric, hyphens, underscores)
      const validSlug = /^[a-z0-9-_]+$/i.test(localProjectName);
      if (!validSlug) {
        setError('Project name can only contain letters, numbers, hyphens, and underscores');
        return;
      }

      // Check length
      if (localProjectName.length > 50) {
        setError('Project name must be 50 characters or less');
        return;
      }

      await onSubmit(localProjectName);
      setSuccess('Project created successfully!');
      setLocalProjectName(''); // Clear form after success
      if (onProjectNameChange) onProjectNameChange('');
    } catch (err: any) {
      setError(err.message ?? 'Failed to create project');
    } finally {
      setSubmitting(false);
    }
  };

  const handleProjectNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setLocalProjectName(value);
    setCharCount(value.length);
    if (onProjectNameChange) onProjectNameChange(value);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="project-name" className="block text-sm font-medium text-gray-700 mb-2">
          Project Name
        </label>
        <div className="relative">
          <input
            type="text"
            id="project-name"
            value={localProjectName}
            onChange={handleProjectNameChange}
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm pl-10 pr-10"
            placeholder="e.g., my-website"
            maxLength={50}
          />
          <div className="absolute inset-y-0 right-0 flex items-center px-2 text-gray-500 dark:text-gray-400">
            {charCount}/50
          </div>
        </div>
      </div>

      <div className="text-sm text-gray-500 dark:text-gray-400">
        <p>Your site will be available at: <code className="bg-gray-100 dark:bg-gray-800 px-1 py-0 rounded">{localProjectName || 'your-project'}.surdix.example</code></p>
        <p className="mt-1">(Note: Custom domains coming soon)</p>
      </div>

      {error && (
        <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
      )}

      {success && (
        <p className="text-sm text-green-600 dark:text-green-400">{success}</p>
      )}

      <button
        type="submit"
        disabled={submitting}
        className="w-full rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-400 disabled:opacity-50 transition-all duration-200"
      >
        {submitting ? 'Creating...' : 'Create Project'}
      </button>
    </form>
  );
}