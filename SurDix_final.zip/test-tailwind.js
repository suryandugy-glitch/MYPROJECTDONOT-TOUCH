const tailwindcss = require("tailwindcss");

tailwindcss.parse({
  content: [
    {
      raw: "<h1 class='text-3xl font-bold text-center text-gray-900 mb-6'>Test Heading</h1>",
      extension: "html"
    }
  ],
  tailwindConfig: {
    content: ["./test-content.html"],
    theme: {
      extend: {}
    },
    darkMode: 'class'
  }
}).then(result => {
  console.log(result.css);
}).catch(error => {
  console.error(error);
});