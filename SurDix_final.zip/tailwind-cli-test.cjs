const fs = require("fs");
const tailwindcss = require("./node_modules/tailwindcss/dist/lib.js");

// Read the input CSS file
const inputCss = fs.readFileSync("./simple-index.css", "utf8");

tailwindcss.compile(
  "<h1 class='text-red-500'>Simple Test</h1>", // First parameter: content as string
  {
    from: undefined, // Second parameter: options
    tailwindConfig: {
      content: [],
      theme: {
        extend: {}
      }
    }
  }
).then(result => {
  console.log('Result properties:', Object.keys(result));
  // Try to get the CSS using the build method with our input CSS
  const builtCss = result.build(inputCss);
  console.log('Built CSS type:', typeof builtCss);
  if (typeof builtCss === 'string') {
    console.log('Generated CSS length:', builtCss.length);
    console.log('First 500 chars:', builtCss.substring(0, 500));

    // Check if our class is in the CSS
    if (builtCss.includes('text-red-500')) {
      console.log('SUCCESS: Found text-red-500 in CSS!');
    } else {
      console.log('FAILURE: Did not find text-red-500 in CSS');
    }
  } else {
    console.log('Built CSS is not a string:', typeof builtCss);
    // Let's see what it is
    console.log('Built CSS:', builtCss);
  }
}).catch(error => {
  console.error('Error:', error);
});