const fs = require("fs");
const path = require("path");
const tailwindcss = require("@tailwindcss/node");

// Read the input CSS file
const inputCss = fs.readFileSync("./simple-index.css", "utf8");

// Get the base directory (directory of the CSS file)
const baseDir = path.dirname(path.resolve("./simple-index.css"));

tailwindcss.compile(inputCss, {
  base: baseDir,
  onDependency: (path) => {
    // This function is called for each dependency
    // We can ignore it for now or log it if needed
    // console.log("Dependency:", path);
  },
  // We can also specify other options if needed
  // For content, we need to specify it in the CSS itself using @content or similar
  // But for now, let's try without explicit content and see if it works
}).then(result => {
  console.log('Result properties:', Object.keys(result));
  // The build method takes candidates (string[]) and returns the CSS as a string
  // For now, let's pass an empty array and see what we get
  const builtCss = result.build([]);
  console.log('Built CSS type:', typeof builtCss);
  if (typeof builtCss === 'string') {
    console.log('Generated CSS length:', builtCss.length);
    console.log('First 500 chars:', builtCss.substring(0, 500));

    // Check if our class is in the CSS
    if (builtCss.includes('text-red-500')) {
      console.log('SUCCESS: Found text-red-500 in CSS!');
    } else {
      console.log('FAILURE: Did not find text-red-500 in CSS');
    }
  } else {
    console.log('Built CSS is not a string:', typeof builtCss);
    // Let's see what it is
    console.log('Built CSS:', builtCss);
  }
}).catch(error => {
  console.error('Error:', error);
});