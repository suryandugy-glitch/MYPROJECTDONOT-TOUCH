/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./simple-test.html",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}