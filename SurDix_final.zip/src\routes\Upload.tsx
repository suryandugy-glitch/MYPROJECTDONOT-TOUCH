import { RequireAuth } from '../components/RequireAuth';
import { UploadZone } from '../components/upload/UploadZone';
import { ProjectForm } from '../components/upload/ProjectForm';
import { useState } from 'react';

export function Upload() {
  const [projectName, setProjectName] = useState('');
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'processing' | 'success' | 'error'>('idle');
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [deploymentUrl, setDeploymentUrl] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);

  // Mock upload function - will be replaced with real implementation
  const handleUpload = async (_file: File): Promise<void> => {
    setUploadStatus('uploading');
    setUploadError(null);
    setDeploymentUrl(null);
    setProgress(0);

    // In a real implementation, this would:
    // 1. Send file to backend server
    // 2. Backend would extract ZIP and validate contents
    // 3. Backend would deploy to hosting provider
    // 4. Return deployment ID and URL

    // Simulate upload progress
    for (let i = 0; i <= 100; i += 10) {
      setProgress(i);
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    // Simulate processing
    setUploadStatus('processing');
    setProgress(0);
    for (let i = 0; i <= 100; i += 10) {
      setProgress(i);
      await new Promise(resolve => setTimeout(resolve, 150));
    }

    // For now, simulate success after delay
    setUploadStatus('success');
    setDeploymentUrl('https://example-project.pages.dev');
    setProgress(100);
  };

  // Mock project creation function
  const handleCreateProject = async (projectName: string): Promise<void> => {
    // In a real implementation, this would:
    // 1. Create project record in database
    // 2. Return project ID

    // For now, simulate success after delay
    setProjectName(projectName);
    return new Promise((resolve) => {
      setTimeout(resolve, 1000);
    });
  };

  return (
    <RequireAuth>
      <div className="bg-white dark:bg-gray-900">
        <header className="bg-white dark:bg-gray-800 shadow-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex">
                <div className="flex-shrink-0 flex items-center">
                  <span className="text-xl font-semibold text-indigo-600 dark:text-indigo-400">Upload Website</span>
                </div>
              </div>
            </div>
          </div>
        </header>
        <main className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                  Upload Your Static Website
                </h2>
                <p className="mt-2 text-gray-600 dark:text-gray-400">
                  Drag and drop your ZIP file or click to select. Make sure it contains
                  an index.html file at the root.
                </p>
              </div>

              <div className="grid gap-6 lg:grid-cols-2">
                <div className="space-y-6">
                  <ProjectForm onSubmit={handleCreateProject} projectName={projectName} onProjectNameChange={setProjectName} />
                </div>

                <div>
                  <UploadZone
                    onUpload={handleUpload}
                    uploadStatus={uploadStatus}
                    progress={progress}
                  />
                </div>
              </div>

              {/* Deployment status section */}
              {uploadStatus !== 'idle' && (
                <div className="mt-8">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-4">
                    Deployment Status
                  </h3>
                  <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6">
                    {uploadStatus === 'uploading' && (
                      <div className="space-y-4">
                        <p className="text-gray-600 dark:text-gray-400">
                          Uploading to Supabase Storage...
                        </p>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mb-2">
                          <div className="bg-indigo-600 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                        </div>
                        <p className="text-right text-sm text-gray-500 dark:text-gray-400">
                          {progress}%
                        </p>
                      </div>
                    )}
                    {uploadStatus === 'processing' && (
                      <div className="space-y-4">
                        <p className="text-gray-600 dark:text-gray-400">
                          Deploying to Cloudflare Pages...
                        </p>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mb-2">
                          <div className="bg-indigo-600 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                        </div>
                        <p className="text-right text-sm text-gray-500 dark:text-gray-400">
                          {progress}%
                        </p>
                      </div>
                    )}
                    {uploadStatus === 'success' && deploymentUrl !== null && (
                      <div className="space-y-4">
                        <p className="text-green-600">
                          Deployment successful! Your site is live at:
                        </p>
                        <a
                          href={deploymentUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-indigo-600 underline hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300"
                        >
                          {deploymentUrl}
                        </a>
                      </div>
                    )}
                    {uploadStatus === 'error' && (
                      <div className="space-y-4">
                        <p className="text-red-600">
                          {uploadError ?? 'An error occurred during upload/deployment.'}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </RequireAuth>
  );
}
